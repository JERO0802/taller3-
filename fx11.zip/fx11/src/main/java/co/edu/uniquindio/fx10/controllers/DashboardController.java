package co.edu.uniquindio.fx10.controllers;


import co.edu.uniquindio.fx10.App;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.VBox;
import java.io.IOException;


public class DashboardController {

    @FXML
    private VBox contenedorPrincipal;

    @FXML
    private void onVerProductos() {
        cargarVista("/co/edu/uniquindio/fx10/vista/ListadoProducto.fxml");
    }

    @FXML
    private void onCrearProducto() {
        cargarVista("/co/edu/uniquindio/fx10/vista/FormularioProducto.fxml");
    }

    private void cargarVista(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(App.class.getResource(fxmlPath));
            Parent nuevaVista = loader.load();

            contenedorPrincipal.getChildren().clear();
            contenedorPrincipal.getChildren().add(nuevaVista);

        } catch (IOException e) {
            System.err.println("Error al cargar la vista: " + fxmlPath);
            e.printStackTrace();
        }
    }

    public VBox getContenedorPrincipal() {
        return contenedorPrincipal;
    }
}
